#pragma once
#include <iostream>
#include "raylib.h"
#include "Entity.h"

class spaceship : public Entity {
public:
	spaceship();
};
