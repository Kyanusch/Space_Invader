#pragma once
#include "spaceship.h"
#include <iostream>
#include "raylib.h"

spaceship::spaceship() : Entity({ 10.0f, 0.0f, 0.0f }, { 0.0f,0.0f,0.0f }, 3, 3, 3) {}